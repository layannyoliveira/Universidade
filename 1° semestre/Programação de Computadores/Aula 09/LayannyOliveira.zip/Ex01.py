carneiros = 0

while True:
    res = input("Já dpormiu?")
    if res =="s" or res == "S":
        break
    else:
        carneiros = carneiros +1

print(carneiros)
    
