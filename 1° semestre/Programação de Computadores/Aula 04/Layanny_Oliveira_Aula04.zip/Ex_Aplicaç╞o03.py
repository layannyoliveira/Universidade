idade = int(input("Qual a sua idade?"))

meses = idade * 12

dias = meses * 30

print("Você tem %.0f, %.0f meses e %.0f dias vividos" % (idade, meses, dias))