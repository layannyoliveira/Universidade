horas = int(input("Qual é a hora?\n" ))

minutos = horas * 60

print("%.0f horas tem %.0f minutos" % (horas, minutos))
