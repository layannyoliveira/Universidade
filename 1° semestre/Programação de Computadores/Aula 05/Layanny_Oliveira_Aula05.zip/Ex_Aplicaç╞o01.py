num = int(input("Informe o numero?"))
if num >= 0 and num <= 9:
    print("Valor correto ")
else:
    print("Valor incorreto")