num = 0
while num <= 100:
    print("Numeros pares de 0 ate 100")
    print(num)
    num = num +2