num = 1
while num <= 50:
    print("Numeros de 1 a 50")
    print(num)
    num = num +1
num = 52
while num <= 100:
    print("Numeros de 52 a 100")
    print(num)
    num = num+2