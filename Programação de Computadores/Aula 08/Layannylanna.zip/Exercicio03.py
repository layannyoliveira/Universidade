num = int(input("Informe o numero:"))

for i in range(1,num+1):
    res = 1 + 1/i
    print("1/",i,"+")
print(res)